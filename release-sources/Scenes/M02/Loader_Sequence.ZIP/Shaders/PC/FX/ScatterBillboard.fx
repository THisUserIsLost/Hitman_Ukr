// Rendering of scatter billboards

#include "Common.fx"

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

float	ScatterWidth;
float	ScatterHeight;
float	ScatterRandomHeight;
float4	v4ScatterBillboard[16];		// Texture coords table

// This one should match ZRenderMaterialSubClassScatterD3D constructor!
// a2v = application2vertex
struct a2vStandard 
{
	float4	v4Position:	POSITION;	
	float4	v4Diffuse:	COLOR0;	
	float4	v4Info:		POSITION1;
};

// v2f - vertex to fragment
struct v2fStandardAmbient10 
{
	float4	Position:	POSITION;
	float4	Diffuse:	COLOR0;	
	float	vFog:		FOG;
	float2	v4Tex:		TEXCOORD0;
};

// Fragment to surface
struct f2sStandard 
{
	float4 col:		COLOR0;			// [0;1] range
};


v2fStandardAmbient10 Ambient_VS11(a2vStandard IN)
{
	v2fStandardAmbient10 OUT;
/*	
	float2 uv[4];
	uv[0] = float2(0,1);
	uv[1] = float2(0,0);
	uv[2] = float2(1,0);
	uv[3] = float2(1,1);
*/
	float2 offset[4];
	offset[0] = float2(-0.5f,0);
	offset[1] = float2(-0.5f,1);
	offset[2] = float2( 0.5f,1);
	offset[3] = float2( 0.5f,0);
	
	float uvidx = lerp(IN.v4Info.x, (3 - IN.v4Info.x), IN.v4Info.z);		// Vertex flip that results in texture flip
	float idx = (IN.v4Info.w * 4) + uvidx;

	float scale = IN.v4Diffuse.a;
	float4 vPos = mul(m44ModelView, IN.v4Position);
	vPos.x += offset[IN.v4Info.x].x * ScatterWidth * scale;
	vPos.y += offset[IN.v4Info.x].y * ScatterHeight * scale;
	vPos.y += offset[IN.v4Info.x].y * (IN.v4Info.y * ScatterRandomHeight * (1.0 / 255.0)) * scale;
	
	CalculateFog(OUT.vFog, IN.v4Position.xyz);	
	vPos = mul(vPos, m44Proj);
	//vPos.z *=  go_vZBiasOffset.x; // Bias
	//vPos.z += -go_vZBiasOffset.y * m44ModelViewProj[2][2]; // Offset
	//vPos.w += -go_vZBiasOffset.y * m44ModelViewProj[3][2]; // Offset
	OUT.Position = vPos;
	
//	OUT.v4Tex.xy = uv[uvidx].xy;
	OUT.v4Tex.xy = v4ScatterBillboard[idx].xy;
	
	OUT.Diffuse.rgb = IN.v4Diffuse.rgb;
	OUT.Diffuse.a = 1;
	return OUT;
}

f2sStandard Ambient_PS11(v2fStandardAmbient10 IN) 
{
	f2sStandard OUT;
//	OUT.col = tex2D(samplerDiffuse, IN.v4Tex.xy).rgba;
	OUT.col = tex2D(samplerDiffuse, IN.v4Tex.xy).rgba * float4(IN.Diffuse.rgb, 1);
//	OUT.col = IN.Diffuse;	
	return OUT;
}

technique Ambient_VS11_PS11 < string Identifier="Ambient"; > 
{
	pass p0 
	{
		VertexShader=compile vs_1_1 Ambient_VS11();
		PixelShader=compile ps_1_1 Ambient_PS11();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=NONE;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;		// where do you come from? max object settings?
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}

//////////////////////////////////////////////
// Postfilter pass..

struct v2fStandardZPass {
	float4 Position:	POSITION;
	float4 Diffuse:		COLOR0;
	float2 v4Tex:		TEXCOORD0;
	float1 vFog:		FOG;
};

f2sStandard ZPass_PS11(v2fStandardZPass IN) 
{
	f2sStandard OUT;
	float4 cTexel=tex2D(samplerDiffuse,IN.v4Tex.xy);
	OUT.col.rgb=IN.Diffuse.rgb;
	OUT.col.a=CalculateAlpha(cTexel.a);
	return OUT;
}

v2fStandardZPass ZPass_VS11(a2vStandard IN)
{
	v2fStandardZPass OUT;

	float2 offset[4];
	offset[0] = float2(-0.5f,0);
	offset[1] = float2(-0.5f,1);
	offset[2] = float2( 0.5f,1);
	offset[3] = float2( 0.5f,0);
	
	float uvidx = lerp(IN.v4Info.x, (3 - IN.v4Info.x), IN.v4Info.z);		// Vertex flip that results in texture flip
	float idx = (IN.v4Info.w * 4) + uvidx;

	float scale = IN.v4Diffuse.a;
	float4 vPos = mul(m44ModelView, IN.v4Position);
	vPos.x += offset[IN.v4Info.x].x * ScatterWidth * scale;
	vPos.y += offset[IN.v4Info.x].y * ScatterHeight * scale;
	vPos.y += offset[IN.v4Info.x].y * (IN.v4Info.y * ScatterRandomHeight * (1.0 / 255.0)) * scale;
	
	CalculateFog(OUT.vFog, IN.v4Position.xyz);	
	vPos = mul(vPos, m44Proj);
	OUT.Position = vPos;
	
	OUT.v4Tex.xy = v4ScatterBillboard[idx].xy;
	float f;
	CalculateFog(f,IN.v4Position.xyz);
	OUT.Diffuse.rgb=1-f.rrr;
	OUT.Diffuse.a=1;
	return OUT;
}

technique ZPass_VS11_PS11 < string Identifier="PostFilterZPass"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 ZPass_VS11();
		PixelShader=compile ps_1_1 ZPass_PS11();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=NONE;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=false;
	}
}

