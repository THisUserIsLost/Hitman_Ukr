#include "StandardCommon.fx"

//
//	Fur shader for Shader Model 1.1 hardware
//

#if defined(FINSENABLED)

texture mapFins;
sampler samplerFins = sampler_state {
	texture =<mapFins>;
	minFilter=Linear;
	magFilter=Linear;
	mipFilter=Linear;
	AddressU=Wrap;
	AddressV=Wrap;
	AddressW=Wrap;
};

texture anisoMap;
sampler samplerAniso = sampler_state {
	texture =<anisoMap>;
	minFilter=LINEAR;
	magFilter=LINEAR;
	mipFilter=LINEAR;
	AddressU=CLAMP;
	AddressV=CLAMP;
	AddressW=CLAMP;
};

float FinLength;

struct v2fFins
{
    float4 Position	: POSITION;
    float3 TexAniso		: TEXCOORD0;
	float3 TexDiffuse	: TEXCOORD1;
	float3 vLightDirTS	: TEXCOORD2;
	float3 vHalfDirTS	: TEXCOORD3;
	float4 Transparency	: COLOR0;
};

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/*float4 PS_Fins(v2fFins IN): COLOR
{
	float4 color=tex2D(samplerFins, IN.TexCoord0.xy);
	return float4(color.rgb,IN.Transparency.r*color.a);
}*/

#if defined(MESH_STANDARD) || defined(MESH_RIGID)

v2fFins VS_Fins(a2vStandard IN) 
{
    v2fFins OUT;

    OUT.Position=mul(IN.v4Position, m44ModelViewProj);
	OUT.TexAniso.xyz=OUT.TexDiffuse=float3(IN.vTexCoords.xy,0);
	
	float4 WorldNormal=normalize(mul(m44World,float4(tosigned(IN.v3Normal),0)));
	float4 WorldPosition=mul(m44World,IN.v4Position);
	float3 WorldEyeDir=normalize(v4EyePosWorld.xyz-WorldPosition.xyz);
	
	//face forward normal (renderman style)
	if(dot(WorldNormal.xyz,WorldEyeDir.xyz)<0) 
	{
		WorldNormal=-WorldNormal;
	}
    OUT.Transparency=saturate(dot(WorldNormal.xyz,WorldEyeDir.xyz)).xxx;
    OUT.Transparency=pow(OUT.Transparency,2);
    
    //calc anisotropic
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	float3 vEyeDirOS=v4EyePosObject.xyz-IN.v4Position.xyz;
	float3 vLightDirOS=v4LightPosObject.xyz-IN.v4Position.xyz;
	OUT.vLightDirTS=mul(m33TangentSpace,vLightDirOS);
	float3 vEyeDirTS=normalize(mul(m33TangentSpace,vEyeDirOS));
	OUT.vHalfDirTS=normalize(OUT.vLightDirTS+vEyeDirTS);
    
    return OUT;
}

technique FurFins < string Identifier="FurFins";//string Performance="Fastest"; 
> {
	pass Fins
    {		
		VertexShader = compile vs_1_1 VS_Fins();
		PixelShader  = asm {	//compile ps_1_1 PS_Fins();
			ps.1.1
			
			tex t0 ; Contains direction of anisotropy in tangent space
			tex t1 ; diffuse base map w. shells hairinfo in alpha
			texm3x2pad t2, t0_bx2	; Perform first row of matrix multiply.
			texm3x2tex t3, t0_bx2	; Perform second row of matrix multiply to get a
									; 3-vector with which to sample texture 3, which is
									; a look-up table for aniso lighting
									
			mul r0.rgb, t3, t1	; diffusemap * aniso light
			mul r0.a,	v0,	t1	; IN.Transparency.r*diffusemap.a
		};
		
		Texture[0] = <anisoMap>;
		Texture[1] = <mapFins>;
		//these two stages are reserved for the texm3x2 instructions
		//Texture[2]
		//Texture[3]
		
		ZWriteEnable=false;
		AlphaTestEnable=false;
		AlphaBlendEnable = true;	//change to true when done w. lightcalc
		SrcBlend = srcalpha;
		DestBlend = invsrcalpha;//
		cullmode = none;
			
		FogEnable=false;	//fog f*** up!
		//FogEnable=<FogEnabled>;
		//FogColor=<vFogColor>;
    }
}
#endif	//defined(MESH_STANDARD) || defined(MESH_RIGID)

#if defined(MESH_WEIGHTED)

v2fFins VS_FinsMPS(a2vStandardMPS IN) 
{
    v2fFins OUT;

    int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(tosigned(IN.v3Normal),i,w);
	float3 v3TangentOut=Do4MPS(tosigned(IN.v3Tangent),i,w);
	float3 v3BinormalOut=tosigned(IN.v3Binormal);	//not skinned - generates too many instructions for vs_1_1!
	
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	OUT.TexAniso.xyz=OUT.TexDiffuse=float3(IN.vTexCoords.xy,0);
	
	float4 WorldNormal=normalize(mul(m44World,float4(v3NormalOut,0)));
	float4 WorldPosition=mul(m44World,v4PositionOut);
	float3 WorldEyeDir=normalize(v4EyePosWorld.xyz-WorldPosition.xyz);
	
	//face forward normal (renderman style)
	if(dot(WorldNormal.xyz,WorldEyeDir.xyz)<0) 
	{
		WorldNormal=-WorldNormal;
	}
    OUT.Transparency=saturate(dot(WorldNormal.xyz,WorldEyeDir.xyz)).xxxx;
    OUT.Transparency=pow(OUT.Transparency,2);
    
    //calc anisotropic
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,v3TangentOut,v3BinormalOut,v3NormalOut);
	float3 vEyeDirOS=v4EyePosObject.xyz-v4PositionOut.xyz;
	float3 vLightDirOS=v4BonesLights11[1].xyz-v4PositionOut.xyz;
	OUT.vLightDirTS=mul(m33TangentSpace,vLightDirOS);
	float3 vEyeDirTS=normalize(mul(m33TangentSpace,vEyeDirOS));
	OUT.vHalfDirTS=normalize(OUT.vLightDirTS+vEyeDirTS);
    
    return OUT;
}

technique FurFinsMPS < string Identifier="FurFinsMPS";//string Performance="Fastest"; 
> {
    pass Fins
    {		
		VertexShader = compile vs_1_1 VS_FinsMPS();
		PixelShader  = asm {	//compile ps_1_1 PS_Fins();
			ps.1.1
			
			tex t0 ; Contains direction of anisotropy in tangent space
			tex t1 ; diffuse base map w. shells hairinfo in alpha
			texm3x2pad t2, t0_bx2	; Perform first row of matrix multiply.
			texm3x2tex t3, t0_bx2	; Perform second row of matrix multiply to get a
									; 3-vector with which to sample texture 3, which is
									; a look-up table for aniso lighting
									
			mul r0.rgb, t3, t1	; diffusemap * aniso light
			mul r0.a,	v0,	t1	; IN.Transparency.r*diffusemap.a
		};
		
		Texture[0] = <anisoMap>;
		Texture[1] = <mapFins>;
		//these two stages are reserved for the texm3x2 instructions
		//Texture[2]
		//Texture[3]
		
		ZWriteEnable=false;
		AlphaTestEnable=false;
		AlphaBlendEnable = true;	//change to true when done w. lightcalc
		SrcBlend = srcalpha;
		DestBlend = invsrcalpha;//
		cullmode = none;
			
		FogEnable=false;	//fog f*** up!
		//FogEnable=<FogEnabled>;
		//FogColor=<vFogColor>;
    }
}
#endif	//MESH_WEIGHTED
#endif	//FINSENABLED