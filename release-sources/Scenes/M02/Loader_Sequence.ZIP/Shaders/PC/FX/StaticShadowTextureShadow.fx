#include "Common.fx"

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

struct a2vStandard {
	float4	v4Position:	POSITION;	
	float4	v4Diffuse:	COLOR0;	
};

struct v2fStandardAmbient10 {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;	
	float vFog:			FOG;
	float4 Tex0:			TEXCOORD0;
};

// Fragment to surface
struct f2sStandard {
	float4 col:		COLOR0;
};

float4x4 m44StaticShadowProjectionMatrix;

v2fStandardAmbient10 Ambient_VS11(a2vStandard IN)
{
	v2fStandardAmbient10 OUT;	
	CalcPosition(OUT.Position,IN.v4Position);				
	OUT.Diffuse=IN.v4Diffuse.a*(1-vStaticShadowColor);
	OUT.Tex0 = mul(IN.v4Position, m44StaticShadowProjectionMatrix);	
	CalculateFog(OUT.vFog,IN.v4Position.xyz);	
	return OUT;
}

f2sStandard Ambient_PS20(v2fStandardAmbient10 IN) 
{
	f2sStandard OUT;		
	float4 p = tex2Dproj( samplerDiffuse, IN.Tex0);			
	OUT.col=p*IN.Diffuse;
	return OUT;
}

technique Ambient_VS11_PS11 <string Identifier="Ambient"; > {
	
	pass p0 
	{
		VertexShader=compile vs_1_1 Ambient_VS11();
		PixelShader=compile ps_2_0 Ambient_PS20();		
		
		AlphaBlendEnable=true;
		SrcBlend=One;
		DestBlend=One;
		AlphaTestEnable=false;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,0);
	}
}

v2fStandardAmbient10 Ambient_VS1_1(a2vStandard IN)
{
	v2fStandardAmbient10 OUT;	
	CalcPosition(OUT.Position,IN.v4Position);				
	OUT.Diffuse=IN.v4Diffuse.a*(1-vStaticShadowColor);
	OUT.Tex0 = mul(IN.v4Position, m44StaticShadowProjectionMatrix);	
	OUT.Tex0.z=OUT.Tex0.w;
	CalculateFog(OUT.vFog,IN.v4Position.xyz);	
	return OUT;
}

f2sStandard Ambient_PS11(v2fStandardAmbient10 IN) 
{
	f2sStandard OUT;		
	OUT.col = tex2D( samplerDiffuse, IN.Tex0.xyz)*IN.Diffuse;			
	return OUT;
}

technique Ambient_VS11_PS11 <string Identifier="Ambient"; string Performance="Fastest"; > {
	pass p0 {
		VertexShader=compile vs_1_1 Ambient_VS1_1();
		PixelShader=asm {	//compile ps_1_1 Ambient_PS11();		
			ps.1.1
			
			tex t0	//projected
			mul r0,	t0, v0
		};
		Texture[0] = <mapDiffuse>;
		TEXTURETRANSFORMFLAGS[0] = 256;	//projected
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,0);
	}
}

technique Ambient_VS11_PS00 <string Identifier="Ambient"; > {
	pass p0 {
		VertexShader=compile vs_1_1 Ambient_VS1_1();
		PixelShader=NULL;
		
		Texture[0] = <mapDiffuse>;
		TEXTURETRANSFORMFLAGS[0] = 256;	//projected
		
		ColorOp[0]=MODULATE;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		ColorOp[1]=DISABLE;		
		
		AlphaOp[0]=MODULATE;
		AlphaArg0[0]=TEXTURE;
		AlphaArg1[0]=DIFFUSE;
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,0);
	}
}