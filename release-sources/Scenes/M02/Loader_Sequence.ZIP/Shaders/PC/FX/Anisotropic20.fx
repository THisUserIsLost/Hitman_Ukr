#include "StandardCommon.fx"

texture anisoMap;
sampler samplerAniso = sampler_state {
	texture =<anisoMap>;
	minFilter=LINEAR;
	magFilter=LINEAR;
	mipFilter=LINEAR;
	AddressU=CLAMP;
	AddressV=CLAMP;
	AddressW=CLAMP;
};

float4 v4AnisoColor;

void CalculateLightingAnisoVS(out float3 vLightDirOut, out float3 vHalfDirOut, out float3 vEyeDirOut, out float4 vLightDirScaledOut, out float4 vPosLightSpaceOut, float4 vPosition, float3x3 m33TangentSpace) {

	// Calculate diffuse term
	float3 vLightDirObject=v4LightPosObject.xyz-vPosition.xyz;
	float3 v3EyeDirObject=v4EyePosObject.xyz-vPosition.xyz;
	float3 vLightDirTangentSpace=mul(m33TangentSpace,vLightDirObject);
	float3 vEyeDirTangentSpace=mul(m33TangentSpace,v3EyeDirObject);
	vLightDirOut=normalize(vLightDirTangentSpace.xyz);
	vEyeDirOut=normalize(vEyeDirTangentSpace.xyz);
	
	// Output half angle vector for specular term
	vHalfDirOut=normalize(vEyeDirTangentSpace)+vLightDirOut;

	// Output scaled light direction for attenuation
	vLightDirScaledOut.xyz=vLightDirObject*v4LightAttributes.y;
	vLightDirScaledOut.w=v4LightAttributes.x;
	// Output position in light space to create back clipping
	vPosLightSpaceOut=mul(m44WorldLightClipProj,vPosition);
}

void CalculateColorAnisoVS(out float4 vDiffuseOut, out float4 vSpecularOut, float4 vDiffuseIn) {
	// Output diffuse color
	vDiffuseOut.rgb=v4LightAttributes.zzz*v4DiffuseColor.rgb*v4LightColor.rgb*vDiffuseIn.rgb;
#ifdef BLENDENABLED
	vDiffuseOut.a=vDiffuseIn.a*v4Opacity.a;
#else
	vDiffuseOut.a=1;
#endif
	// Output specular color
	vSpecularOut=v4LightAttributes.zzzz*v4AnisoColor*v4LightColor;
}



//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
#if defined(MESH_STANDARD) || defined(MESH_TWEENED)

struct v2fStandardAmbientHQ20 {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;
	float4 Specular:		COLOR1;
	float4 vTexCoords:		TEXCOORD0;
	float3 vLightDirTS:		TEXCOORD1;
	float3 vEyeDirTS:		TEXCOORD2;
	float3 vHalfDirTS:		TEXCOORD3;
	float4 Ambient:			TEXCOORD4;
	float vFog:				FOG;
};

v2fStandardAmbientHQ20 AmbientHQ_VS20(a2vStandardHQ IN)
{
	v2fStandardAmbientHQ20 OUT;
	
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	
	float3 vEyeDirOS=v4EyePosObject.xyz-IN.v4Position.xyz;
	float3 vLightDirOS=tosigned(IN.vLightDir.xyz);
	
	OUT.vLightDirTS=mul(m33TangentSpace,vLightDirOS);
	OUT.vEyeDirTS=normalize(mul(m33TangentSpace,vEyeDirOS));
	OUT.vHalfDirTS=normalize(OUT.vLightDirTS+OUT.vEyeDirTS);

	OUT.Ambient=IN.v4Ambient*v4DiffuseColor;
	OUT.Diffuse.rgb=IN.vLightCol.rgb*v4DiffuseColor.rgb;
	OUT.Diffuse.a=IN.vLightCol.a*v4Opacity.a*2;
	OUT.Specular=IN.vLightCol*v4AnisoColor;
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif
	
	CalcPosition(OUT.Position,IN.v4Position);
	CalculateFog(OUT.vFog,OUT.Position.xyz);
	
	return OUT;
}

f2sStandard AmbientHQ_PS20(v2fStandardAmbientHQ20 IN) 
{
	f2sStandard OUT;
	float2 vTexCoords;
	CalculateTexCoordsPS(vTexCoords,IN.vTexCoords,IN.vEyeDirTS);
	float3 v3BumpNormal=CalculateBumpNormalPS(vTexCoords);
	float4 cTexel=tex2D(samplerDiffuse,vTexCoords);
	
	// Ambient
	OUT.col.rgb=IN.Ambient.rgb*cTexel.rgb;
	
	float3 vLightDirTS=IN.vLightDirTS;
	float3 vHalfDirTS=normalize(IN.vHalfDirTS);
	float vDiffuseIntensity=saturate(dot(v3BumpNormal,vLightDirTS));
	float vSpecularIntensity=saturate(dot(v3BumpNormal,vHalfDirTS));
	float4 cAni=tex2D(samplerAniso,float2(vDiffuseIntensity,vSpecularIntensity));
	float3 v3DiffuseColor=cAni.rgb*IN.Diffuse.rgb*cTexel.rgb;
	float3 v3SpecularColor=cAni.a*IN.Specular;
	OUT.col.rgb+=v3DiffuseColor+v3SpecularColor;
	
	OUT.col.rgb=CalculateDebugColorPS(OUT.col.rgb*2,cTexel);
	OUT.col.a=CalculateAlpha(IN.Diffuse.a*cTexel.a);
	
	return OUT;
}

technique AmbientHQ_VS20_PS20 < string Identifier="Ambient"; > {
	pass p0 {
		VertexShader=compile vs_1_1 AmbientHQ_VS20();
		PixelShader=compile ps_2_0 AmbientHQ_PS20();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif

//////////////////////////////////////////////////////////////////
// High quality ambient pass
//////////////////////////////////////////////////////////////////
#if defined(MESH_WEIGHTED) || defined(MESH_RIGID)
struct v2fStandardAmbientMPSHQ {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;
	float2 vTexCoords:	TEXCOORD0;
	float3 vLightDir1TS:	TEXCOORD1;
	float3 vLightDir2TS:	TEXCOORD2;
	float3 vLightDir3TS:	TEXCOORD3;
	float3 vHalfDir1TS:		TEXCOORD4;
	float3 vHalfDir2TS:		TEXCOORD5;
	float3 vHalfDir3TS:		TEXCOORD6;
	float vFog:				FOG;
};

f2sStandard AmbientHQ_MPS_PS20(v2fStandardAmbientMPSHQ IN) 
{
	f2sStandard OUT;
	float2 vTexCoords=IN.vTexCoords;
	//CalculateTexCoordsPS(vTexCoords,IN.vTexCoords,IN.vEyeDirTS);
	float3 v3BumpNormal=CalculateBumpNormalPS(vTexCoords);
	float4 cTexel=tex2D(samplerDiffuse,vTexCoords);
	
	float3 vLightDir1TS=IN.vLightDir1TS;
	float3 vLightDir2TS=IN.vLightDir2TS;
	float3 vLightDir3TS=IN.vLightDir3TS;
	float3 vHalfDir1TS=normalize(IN.vHalfDir1TS);
	float3 vHalfDir2TS=normalize(IN.vHalfDir2TS);
	float3 vHalfDir3TS=normalize(IN.vHalfDir3TS);
	
	float vDiffuseDot1=saturate(dot(v3BumpNormal,vLightDir1TS));
	float vDiffuseDot2=saturate(dot(v3BumpNormal,vLightDir2TS));
	float vDiffuseDot3=saturate(dot(v3BumpNormal,vLightDir3TS));
	float vSpecularDot1=saturate(dot(v3BumpNormal,vHalfDir1TS));
	float vSpecularDot2=saturate(dot(v3BumpNormal,vHalfDir2TS));
	float vSpecularDot3=saturate(dot(v3BumpNormal,vHalfDir3TS));
	float4 cAni1=tex2D(samplerAniso,float2(vDiffuseDot1,vSpecularDot1));
	float4 cAni2=tex2D(samplerAniso,float2(vDiffuseDot2,vSpecularDot2));
	float4 cAni3=tex2D(samplerAniso,float2(vDiffuseDot3,vSpecularDot3));
	
	float3 cAniDiff=cAni1.rgb*v4BonesLights[1].rgb+cAni2.rgb*v4BonesLights[3].rgb+cAni3.rgb*v4BonesLights[5].rgb;
	float3 cAniSpec=cAni1.a*v4BonesLights[1].rgb+cAni2.a*v4BonesLights[3].rgb+cAni3.a*v4BonesLights[5].rgb;
	
	float3 cDiffuse=cAniDiff*cTexel.rgb*v4DiffuseColor.rgb*2;
	float3 cSpecular=cAniSpec*v4AnisoColor.rgb*2;
	
	OUT.col.rgb =v4BonesLights[6].rgb;
	OUT.col.rgb+=cDiffuse+cSpecular;
	
	OUT.col.rgb=CalculateDebugColorPS(OUT.col.rgb,cTexel);
	OUT.col.a=CalculateAlpha(cTexel.a);
	return OUT;
}
#endif

#if defined(MESH_RIGID)
v2fStandardAmbientMPSHQ AmbientHQ_Rigid_VS20(a2vStandardRigid IN)
{
	v2fStandardAmbientMPSHQ OUT;
	
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	
	CalcBonesLightHQ(OUT.vLightDir1TS,OUT.vLightDir2TS,OUT.vLightDir3TS,OUT.vHalfDir1TS,OUT.vHalfDir2TS,OUT.vHalfDir3TS,m33TangentSpace,v4EyePosObject-IN.v4Position);
	OUT.Diffuse.rgb=IN.vVertexCol.rgb;
	OUT.Diffuse.a=IN.vVertexCol.a*v4Opacity.a;
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
	
	CalcPosition(OUT.Position,IN.v4Position);
	CalculateFog(OUT.vFog,OUT.Position.xyz);
	
	return OUT;
}

technique AmbientHQ_Rigid_VS20_PS20 < string Identifier="AmbientRigid"; > {
	pass p0 {
		VertexShader=compile vs_2_0 AmbientHQ_Rigid_VS20();
		PixelShader=compile ps_2_0 AmbientHQ_MPS_PS20();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif


#if defined(MESH_WEIGHTED)
v2fStandardAmbientMPSHQ AmbientHQ_MPS_VS20(a2vStandardMPS IN)
{
	v2fStandardAmbientMPSHQ OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(tosigned(IN.v3Normal),i,w);
	float3 v3TangentOut=Do4MPS(tosigned(IN.v3Tangent),i,w);
	float3 v3BinormalOut=Do4MPS(tosigend(IN.v3Binormal),i,w);
	
	//CalcPosition(OUT.Position,v4PositionOut);
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,v3TangentOut,v3BinormalOut,v3NormalOut);
	
	// Calculate lighting
	CalcBonesLightHQ(OUT.vLightDir1TS,OUT.vLightDir2TS,OUT.vLightDir3TS,OUT.vHalfDir1TS,OUT.vHalfDir2TS,OUT.vHalfDir3TS,m33TangentSpace,v4EyePosObject-v4PositionOut);
	OUT.Diffuse.rgb=IN.v4Diffuse.rgb;
	OUT.Diffuse.a=IN.v4Diffuse.a*v4Opacity.a;

	CalculateFog(OUT.vFog,OUT.Position.xyz);

	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
	
	return OUT;
}

technique AmbientHQ_MPS_VS20_PS20 < string Identifier="AmbientMPS"; > {
	pass p0 {
		VertexShader=compile vs_2_0 AmbientHQ_MPS_VS20();
		PixelShader=compile ps_2_0 AmbientHQ_MPS_PS20();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
struct v2fStandardLighting20 {
	float4 Position:			POSITION;
	float4 Diffuse:				COLOR0;
	float4 Specular:			COLOR1;
	float4 vTexCoords:		TEXCOORD0;
	float3 TexLightDir:			TEXCOORD1;
	float4 TexLightDir2:		TEXCOORD2;
	float3 TexHalfAngleDir:		TEXCOORD3;
	float4 TexEyeDir:			TEXCOORD4;
	float4 vShadowCoords:		TEXCOORD5;
	float4 TexLightClip:		TEXCOORD7;
	float vFog:					FOG;
};

f2sStandard Lighting_PS20(v2fStandardLighting20 IN) {

	f2sStandard OUT;

	// Read base stuff
	float2 vTexCoords;
	CalculateTexCoordsPS(vTexCoords,IN.vTexCoords,IN.TexEyeDir);
	float4 cTexel=tex2D(samplerDiffuse,vTexCoords); 
	float3 v3BumpNormal=CalculateBumpNormalPS(vTexCoords);
	
	float3 vLightAttenuation=CalculateLightIntensity(IN.TexLightClip,IN.TexLightDir2);
	float vShadowAttenuation=GetShadowMapPS(IN.vShadowCoords,IN.TexEyeDir.w);
	
	float3 vResultColor;

	float3 vLightDirTS=normalize(IN.TexLightDir.xyz);
	float3 vHalfDirTS=normalize(IN.TexHalfAngleDir);
	float vDiffuseIntensity=saturate(dot(v3BumpNormal,vLightDirTS));
	float vSpecularIntensity=saturate(dot(v3BumpNormal,vHalfDirTS));
	float4 cAni=tex2D(samplerAniso,float2(vDiffuseIntensity,vSpecularIntensity));
	float3 v3DiffuseColor=cAni.rgb*IN.Diffuse.rgb*cTexel.rgb;
	float3 v3SpecularColor=cAni.a*IN.Specular;
	vResultColor=v3DiffuseColor+v3SpecularColor;

	OUT.col.rgb=vResultColor*vShadowAttenuation*vLightAttenuation;
	OUT.col.a=CalculateAlpha(IN.Diffuse.a*cTexel.a);
	return OUT;
}

#if defined(MESH_STANDARD) || defined(MESH_TWEENED)
v2fStandardLighting20 Lighting_VS20(a2vStandardHQ IN) {
	v2fStandardLighting20 OUT;

	CalcPosition(OUT.Position,IN.v4Position);

	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	CalculateLightingAnisoVS(OUT.TexLightDir,OUT.TexHalfAngleDir,OUT.TexEyeDir.xyz,OUT.TexLightDir2,OUT.TexLightClip,IN.v4Position,m33TangentSpace);
	CalculateColorAnisoVS(OUT.Diffuse,OUT.Specular,IN.vVertexCol);
	GetShadowMapVS(OUT.vShadowCoords,OUT.TexEyeDir.w,IN.v4Position,tosigned(IN.v3Normal));
	CalculateFog(OUT.vFog,OUT.Position.xyz);
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif

	return OUT;
}

technique Lighting_VS20_PS20 < string Identifier="Lighting"; > {
	
	pass p0 {
		VertexShader=compile vs_2_0 Lighting_VS20();
		PixelShader=compile ps_2_0 Lighting_PS20();
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=Equal;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif

#if defined(MESH_RIGID)
v2fStandardLighting20 LightingRigid_VS20(a2vStandardRigid IN) {
	v2fStandardLighting20 OUT;

	CalcPosition(OUT.Position,IN.v4Position);

	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	CalculateLightingAnisoVS(OUT.TexLightDir,OUT.TexHalfAngleDir,OUT.TexEyeDir.xyz,OUT.TexLightDir2,OUT.TexLightClip,IN.v4Position,m33TangentSpace);
	CalculateColorAnisoVS(OUT.Diffuse,OUT.Specular,IN.vVertexCol);
	OUT.Diffuse.a*=CalculateAlphaFade(IN.v4Position,tosigned(IN.v3Normal));
	GetShadowMapVS(OUT.vShadowCoords,OUT.TexEyeDir.w,IN.v4Position,tosigned(IN.v3Normal));
	CalculateFog(OUT.vFog,OUT.Position.xyz);
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif

	return OUT;
}

technique LightingRigid_VS20_PS20 < string Identifier="LightingRigid"; > {
	
	pass p0 {
		VertexShader=compile vs_2_0 LightingRigid_VS20();
		PixelShader=compile ps_2_0 Lighting_PS20();
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif


#if defined(MESH_WEIGHTED)
v2fStandardLighting20 Lighting_MPS_VS20(a2vStandardMPS IN)
{
	v2fStandardLighting20 OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(tosigned(IN.v3Normal),i,w);
	float3 v3TangentOut=Do4MPS(tosigned(IN.v3Tangent),i,w);
	float3 v3BinormalOut=Do4MPS(tosigned(IN.v3Binormal),i,w);
	
	//CalcPosition(OUT.Position,IN.v4Position);
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,v3TangentOut,v3BinormalOut,v3NormalOut);
	CalculateLightingAnisoVS(OUT.TexLightDir,OUT.TexHalfAngleDir,OUT.TexEyeDir.xyz,OUT.TexLightDir2,OUT.TexLightClip,v4PositionOut,m33TangentSpace);
	CalculateColorAnisoVS(OUT.Diffuse,OUT.Specular,IN.v4Diffuse);
	GetShadowMapVS(OUT.vShadowCoords,OUT.TexEyeDir.w,v4PositionOut,v3NormalOut);
	CalculateFog(OUT.vFog,OUT.Position.xyz);
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);

	return OUT;
}

technique Lighting_MPS_VS20_PS2 < string Identifier="LightingMPS"; > {
	
	pass p0 {
		VertexShader=compile vs_2_0 Lighting_MPS_VS20();
		PixelShader=compile ps_2_0 Lighting_PS20();
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=Equal;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif
