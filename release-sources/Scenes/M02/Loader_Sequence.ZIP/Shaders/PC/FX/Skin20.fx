#include "standardcommon.fx"

/*
	Description:
		Skin shader
	Features:
		* PerPixel lighting with rim lighting and translucency (sub surface scattering)
		* Support for skinned models
	Author:
		Mircea Marghidanu
*/

struct f2sSkin {
	float4 col:		COLOR0;
};

//////////////////////////////////////////////////////////////////
// High quality ambient pass
//////////////////////////////////////////////////////////////////
#if defined(MESH_STANDARD) || defined(MESH_TWEENED) || defined(MESH_RIGID)

struct v2fSkinAmbientHQ20 {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;
	float4 Specular:		COLOR1;
	float4 vTexCoords:	TEXCOORD0;
	float3 vLightDirTS:		TEXCOORD1;
	float3 vEyeDirTS:		TEXCOORD2;
	float3 vHalfDirTS:		TEXCOORD3;
	float vFog:				FOG;
};

v2fSkinAmbientHQ20 AmbientHQ_VS20(a2vStandardHQ IN)
{
	v2fSkinAmbientHQ20 OUT;
	
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	
	float3 vEyeDirOS=v4EyePosObject.xyz-IN.v4Position.xyz;
	float3 vLightDirOS=tosigned(IN.vLightDir.xyz);
	
	OUT.vLightDirTS=mul(m33TangentSpace,vLightDirOS);
	OUT.vEyeDirTS=normalize(mul(m33TangentSpace,vEyeDirOS));
	OUT.vHalfDirTS=normalize(OUT.vLightDirTS+OUT.vEyeDirTS);

	//OUT.Diffuse.rgb=CalculateDebugColor(IN.v4Diffuse.rgb*v4DiffuseColor.rgb);
	//OUT.Diffuse.a=IN.v4Diffuse.a*v4Opacity.a;
	OUT.Diffuse.rgb=IN.vLightCol.rgb*v4DiffuseColor.rgb;
	OUT.Diffuse.a=IN.vLightCol.a*v4Opacity.a;
#ifdef SPECULARENABLED
	OUT.Specular=IN.vLightCol*v4SpecularColor;
#else
	OUT.Specular=OUT.Diffuse;
#endif
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif
	
	OUT.Position=mul(IN.v4Position, m44ModelViewProj);
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	
	return OUT;
}

f2sSkin AmbientHQ_PS20(v2fSkinAmbientHQ20 IN) 
{
	f2sSkin OUT;
	float2 vTexCoords;
	CalculateTexCoordsPS(vTexCoords,IN.vTexCoords,IN.vEyeDirTS);
	float3 v3BumpNormal=CalculateBumpNormalPS(vTexCoords);
	float4 cTexel=tex2D(samplerDiffuse,vTexCoords);
	
	float3 vLightDirTS=normalize(IN.vLightDirTS);
	OUT.col.rgb=dot(vLightDirTS,v3BumpNormal)*IN.Diffuse.rgb*cTexel.rgb*2;
	
#ifdef SPECULARENABLED
	float3 vHalfDir=normalize(IN.vHalfDirTS);
	float3 v3SpecularMask=tex2D(samplerSpecularMask,vTexCoords).rgb;
	float vSpecularIntensity=pow(saturate(dot(v3BumpNormal.xyz,vHalfDir)),v4SpecularPower.x)*vSpecularLevel;
	float3 v3SpecularColor=vSpecularIntensity*IN.Specular.rgb*v3SpecularMask*2;
	OUT.col.rgb+=v3SpecularColor;
#endif
	
	OUT.col.rgb=CalculateDebugColorPS(OUT.col.rgb,cTexel);
	OUT.col.a=CalculateAlpha(cTexel.a);
	
	return OUT;
}

technique AmbientHQ_VS20_PS20 < string Identifier="Ambient"; string Performance="Blend";> {
	pass p0 {
		VertexShader=compile vs_1_1 AmbientHQ_VS20();
		PixelShader=compile ps_2_0 AmbientHQ_PS20();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif

#if defined(MESH_WEIGHTED)

//#define COMBINE_3_TO_1

#ifdef COMBINE_3_TO_1
struct v2fSkinAmbientMPSHQ {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;
	float2 vTexCoords:	TEXCOORD0;
	float3 vLightDirTS:		TEXCOORD1;
	float3 vHalfDirTS:		TEXCOORD2;
	float vFog:				FOG;
};

v2fSkinAmbientMPSHQ AmbientHQ_MPS_VS20(a2vStandardMPS IN)
{
	v2fSkinAmbientMPSHQ OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(tosigned(IN.v3Normal),i,w);
	float3 v3TangentOut=Do4MPS(tosigned(IN.v3Tangent),i,w);
	float3 v3BinormalOut=Do4MPS(tosigned(IN.v3Binormal),i,w);
	
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,v3TangentOut,v3BinormalOut,v3NormalOut);
	
	// Calculate lighting
	float3 vEyeDirOS=normalize(v4EyePosObject-v4PositionOut);
	
	float3 fIntensities;
	fIntensities.x=max(0,dot(v4BonesLights[0].xyz,v3NormalOut));
	fIntensities.y=max(0,dot(v4BonesLights[2].xyz,v3NormalOut));
	fIntensities.z=max(0,dot(v4BonesLights[4].xyz,v3NormalOut));
	
	float3 vLightDirOS;
	vLightDirOS=v4BonesLights[0].xyz*fIntensities.x*v4BonesLights[1].a;
	vLightDirOS+=v4BonesLights[2].xyz*fIntensities.y*v4BonesLights[3].a;
	vLightDirOS+=v4BonesLights[4].xyz*fIntensities.z*v4BonesLights[5].a;
	
	float l=length(vLightDirOS);
	vLightDirOS/=l;
	l/=dot(v3NormalOut,vLightDirOS);
	OUT.vLightDirTS.xyz=mul(m33TangentSpace,vLightDirOS);
	OUT.vHalfDirTS=mul(m33TangentSpace,vLightDirOS+vEyeDirOS);
	
	float3 vLightDiffuse;
	vLightDiffuse=v4BonesLights[1].rgb*fIntensities.x;
	vLightDiffuse+=v4BonesLights[3].rgb*fIntensities.y;
	vLightDiffuse+=v4BonesLights[5].rgb*fIntensities.z;
	float fIntensity=dot(vLightDiffuse,float3(0.33,0.33,0.33));
	vLightDiffuse/=fIntensity;
	OUT.Diffuse.rgb=IN.v4Diffuse.rgb*vLightDiffuse*l;
	OUT.Diffuse.a=CalculateAlpha(IN.v4Diffuse.a*v4Opacity.a);

	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);

	CalculateFog(OUT.vFog,v4PositionOut.xyz);
	
	return OUT;
}

f2sSkin AmbientHQ_MPS_PS20(v2fSkinAmbientMPSHQ IN) 
{
	f2sSkin OUT;
	float2 vTexCoords=IN.vTexCoords;
	float3 v3BumpNormal=CalculateBumpNormalPS(vTexCoords);
	float4 cTexel=tex2D(samplerDiffuse,vTexCoords);
	
	float3 vLightDirTS=IN.vLightDirTS;
	OUT.col.rgb=IN.Diffuse.rgb*saturate(dot(vLightDirTS,v3BumpNormal));
	OUT.col.rgb+=v4BonesLights[6].rgb; 
	OUT.col.rgb*=cTexel.rgb*v4DiffuseColor;
	
#ifdef SPECULARENABLED
	float3 vHalfDir=normalize(IN.vHalfDirTS);
	float3 v3SpecularMask=tex2D(samplerSpecularMask,vTexCoords).rgb;
	float3 vSpecular=IN.Diffuse.rgb*pow(saturate(dot(v3BumpNormal.xyz,vHalfDir)),v4SpecularPower.x);
	float3 v3SpecularColor=vSpecular*v3SpecularMask*vSpecularLevel*v4SpecularColor;
	OUT.col.rgb+=v3SpecularColor;
#endif

	OUT.col.rgb=CalculateDebugColorPS(OUT.col.rgb*2,cTexel);
	OUT.col.a=CalculateAlpha(cTexel.a*IN.Diffuse.a);
	return OUT;
}

#else

struct v2fSkinAmbientMPSHQ {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;
	float2 vTexCoords:	TEXCOORD0;
	float3 vLightDir1TS:	TEXCOORD1;
	float3 vLightDir2TS:	TEXCOORD2;
	float3 vLightDir3TS:	TEXCOORD3;
	float3 vHalfDir1TS:		TEXCOORD4;
	float3 vHalfDir2TS:		TEXCOORD5;
	float3 vHalfDir3TS:		TEXCOORD6;
	float vFog:				FOG;
};

v2fSkinAmbientMPSHQ AmbientHQ_MPS_VS20(a2vStandardMPS IN)
{
	v2fSkinAmbientMPSHQ OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(tosigned(IN.v3Normal),i,w);
	float3 v3TangentOut=Do4MPS(tosigned(IN.v3Tangent),i,w);
	float3 v3BinormalOut=Do4MPS(tosigned(IN.v3Binormal),i,w);
	
	//CalcPosition(OUT.Position,v4PositionOut);
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,v3TangentOut,v3BinormalOut,v3NormalOut);
	
	// Calculate lighting
	CalcBonesLightHQ(OUT.vLightDir1TS,OUT.vLightDir2TS,OUT.vLightDir3TS,OUT.vHalfDir1TS,OUT.vHalfDir2TS,OUT.vHalfDir3TS,m33TangentSpace,v4EyePosObject-v4PositionOut);
	OUT.Diffuse.rgb=IN.v4Diffuse.rgb;
	OUT.Diffuse.a=IN.v4Diffuse.a*v4Opacity.a;

	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);

	CalculateFog(OUT.vFog,v4PositionOut.xyz);
	
	return OUT;
}

f2sSkin AmbientHQ_MPS_PS20(v2fSkinAmbientMPSHQ IN) 
{
	f2sSkin OUT;
	float2 vTexCoords=IN.vTexCoords;
	float3 v3BumpNormal=CalculateBumpNormalPS(vTexCoords);
	float4 cTexel=tex2D(samplerDiffuse,vTexCoords);
	
	float3 vLightDir1TS=IN.vLightDir1TS;
	float3 vLightDir2TS=IN.vLightDir2TS;
	float3 vLightDir3TS=IN.vLightDir3TS;
	OUT.col.rgb =v4BonesLights[1].rgb*saturate(dot(vLightDir1TS,v3BumpNormal));
	OUT.col.rgb+=v4BonesLights[3].rgb*saturate(dot(vLightDir2TS,v3BumpNormal));
	OUT.col.rgb+=v4BonesLights[5].rgb*saturate(dot(vLightDir3TS,v3BumpNormal));
	OUT.col.rgb+=v4BonesLights[6].rgb;
	OUT.col.rgb*=cTexel.rgb*v4DiffuseColor;
	
#ifdef SPECULARENABLED
	float3 vHalfDir1=normalize(IN.vHalfDir1TS);
	float3 vHalfDir2=normalize(IN.vHalfDir2TS);
	float3 vHalfDir3=normalize(IN.vHalfDir3TS);
	float3 v3SpecularMask=tex2D(samplerSpecularMask,vTexCoords).rgb;
	float3 vSpecular;
	vSpecular=v4BonesLights[1].rgb*pow(saturate(dot(v3BumpNormal.xyz,vHalfDir1)),v4SpecularPower.x);
	vSpecular+=v4BonesLights[3].rgb*pow(saturate(dot(v3BumpNormal.xyz,vHalfDir2)),v4SpecularPower.x);
	vSpecular+=v4BonesLights[5].rgb*pow(saturate(dot(v3BumpNormal.xyz,vHalfDir3)),v4SpecularPower.x);
	float3 v3SpecularColor=vSpecular*v3SpecularMask*vSpecularLevel*v4SpecularColor;
	OUT.col.rgb+=v3SpecularColor;
#endif
		
	OUT.col.rgb=CalculateDebugColorPS(OUT.col.rgb*2,cTexel);
	OUT.col.a=CalculateAlpha(cTexel.a*IN.Diffuse.a);
	
	return OUT;
}

#endif

technique AmbientHQ_MPS_VS20_PS20 < string Identifier="AmbientMPS"; string Performance="Blend"; > {
	pass p0 {
		VertexShader=compile vs_2_0 AmbientHQ_MPS_VS20();
		PixelShader=compile ps_2_0 AmbientHQ_MPS_PS20();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif

/****************************************************************
		DiffuseBumpSpecularTransRimLight_PS20
 ****************************************************************/

// Vertex to Fragment stuff
struct v2fSkinDiffuse {
    float4 Position     : POSITION;
	float4 Diffuse		: COLOR0;
	float4 Specular		: COLOR1;

	float4 vTexCoords	: TEXCOORD0;
    float3 LightVector  : TEXCOORD1;
    float3 HalfVector	: TEXCOORD2;
    float4 EyeVector	: TEXCOORD3;
    float4 LightVectorOS: TEXCOORD4;
	float4 TexShadow	: TEXCOORD5;
	float4 TexLightClip : TEXCOORD6;
	float3 EyeVectorOS	: TEXCOORD7;
	float vFog:			  FOG;
};

float4 DiffuseBumpSpecularTransRimLight_PS20(v2fSkinDiffuse IN) : COLOR0 
{
	float4 OUT;

	// sampling stage
	float4 color =  tex2D(samplerDiffuse,IN.vTexCoords);
	float3 bumpnormal = CalculateBumpNormalPS(IN.vTexCoords); 
	
	
	float3 v2l = normalize(IN.LightVector);
	float3 v2e = IN.EyeVector;
	float3 hv  = normalize(IN.HalfVector);
	float3 v2lOS = normalize(IN.LightVectorOS);
	float3 v2eOS = IN.EyeVectorOS;
	float3 transweights = tex2D(samplerTranslucency,IN.vTexCoords);

	// add the diffuse and specular lighting contribution
	float diffuse  = saturate(dot(bumpnormal, v2l));
	OUT.rgb = diffuse * color;

	// add the view/light dependent rim lighting
	float  fCosViewNormal=saturate(dot(bumpnormal,v2e));
	float  fSinViewNormal=1.0-fCosViewNormal*fCosViewNormal;
	float  fBackLightStrength=pow(fSinViewNormal,fRimLightPower);
	OUT.rgb += saturate(dot(-v2e,v2l))*fBackLightStrength*v4RimLightColor*fRimLightStrength;
	
	// add the translucency contribution
	OUT.rgb += v4SubSurfaceColor * fSubSurfaceTransparency*abs(dot(transweights,v2eOS))*saturate(dot(-v2e, v2l));

	// And apply lighting	
	OUT.rgb *= IN.Diffuse.rgb;
	
#ifdef SPECULARENABLED
	float3 gloss = tex2D(samplerSpecularMask,IN.vTexCoords);
	float  specular = pow(saturate(dot(bumpnormal, hv)),v4SpecularPower.x) * vSpecularLevel;
	OUT.rgb += IN.Specular.rgb * specular*gloss;
#endif
	
	// light and shadow factor
	OUT.rgb *= CalculateLightIntensity(IN.TexLightClip,IN.LightVectorOS);
	OUT.rgb *= GetShadowMapPS(IN.TexShadow,IN.EyeVector.w);
	
	// final gathering and exit point
	OUT.a = CalculateAlpha(color.w * IN.Diffuse.a);
	return OUT;
}

#if defined(MESH_STANDARD) || defined(MESH_TWEENED) || defined(MESH_RIGID)
/****************************************************************
		DiffuseBumpSpecularTransRimLight_VS20
 ****************************************************************/
v2fSkinDiffuse DiffuseBumpSpecularTransRimLight_VS20(a2vStandardHQ IN) {
	v2fSkinDiffuse OUT;

	//CalcPosition(OUT.Position,IN.v4Position);
	OUT.Position = mul(IN.v4Position, m44ModelViewProj);	

	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	CalculateLightingVS(OUT.LightVector,OUT.HalfVector,OUT.EyeVector.xyz,OUT.LightVectorOS,OUT.TexLightClip,IN.v4Position,m33TangentSpace);
	CalculateColorVS(OUT.Diffuse,OUT.Specular,IN.vVertexCol);
	GetShadowMapVS(OUT.TexShadow,OUT.EyeVector.w,IN.v4Position,tosigned(IN.v3Normal));
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif
	
	OUT.EyeVectorOS=normalize(IN.v4Position-v4EyePosObject);

	return OUT;
}

/****************************************************************
		DiffuseBumpSpecularTransRimLight_VS20_PS20 
 ****************************************************************/
technique DiffuseBumpSpecularTransRimLight_VS20_PS20 < string Identifier="DiffuseBumpSpecularTransRimLight"; > {
	pass p0 {
		VertexShader=compile vs_2_0 DiffuseBumpSpecularTransRimLight_VS20();
		PixelShader=compile  ps_2_0 DiffuseBumpSpecularTransRimLight_PS20();
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=Equal;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif

#if defined(MESH_WEIGHTED)
/****************************************************************
		DiffuseBumpSpecularTransRimLightMPS_VS20
 ****************************************************************/
v2fSkinDiffuse DiffuseBumpSpecularTransRimLightMPS_VS20(a2vStandardMPS IN)
{
	v2fSkinDiffuse OUT;
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(tosigned(IN.v3Normal),i,w);
	float3 v3TangentOut=Do4MPS(tosigned(IN.v3Tangent),i,w);
	float3 v3BinormalOut=Do4MPS(tosigned(IN.v3Binormal),i,w);

	//CalcPosition(OUT.Position,IN.v4Position);
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,v3TangentOut,v3BinormalOut,v3NormalOut);
	CalculateLightingVS(OUT.LightVector,OUT.HalfVector,OUT.EyeVector.xyz,OUT.LightVectorOS,OUT.TexLightClip,v4PositionOut,m33TangentSpace);
	CalculateColorVS(OUT.Diffuse,OUT.Specular,IN.v4Diffuse);
	GetShadowMapVS(OUT.TexShadow,OUT.EyeVector.w,v4PositionOut,v3NormalOut);
	CalculateFog(OUT.vFog,v4PositionOut.xyz);
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
	
	OUT.EyeVectorOS=normalize(v4PositionOut-v4EyePosObject);

	return OUT;
}


/****************************************************************
		DiffuseBumpSpecularTransRimLightMPS_VS20_PS20 
 ****************************************************************/
technique DiffuseBumpSpecularTransRimLightMPS_VS20_PS20 < string Identifier="DiffuseBumpSpecularTransRimLightMPS"; > {
	pass p0 {
		VertexShader=compile vs_2_0  DiffuseBumpSpecularTransRimLightMPS_VS20();
		PixelShader =compile ps_2_0 DiffuseBumpSpecularTransRimLight_PS20();
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=Equal;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif
