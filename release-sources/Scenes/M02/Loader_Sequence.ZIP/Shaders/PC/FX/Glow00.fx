#include "StandardCommon.fx"

struct v2fStandardAmbient10 {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;
	float2 vTexCoords:		TEXCOORD0;
	float  vFog:			FOG;
};

v2fStandardAmbient10 Ambient_VS10(a2vStandard IN)
{
	v2fStandardAmbient10 OUT;
	
#ifdef MESH_TWEENED
	float4 v4Position=lerp(IN.v4Position,IN.v4Position2,vTweenFactor);
	float3 v3Normal=lerp(tosigned(IN.v3Normal),tosigned(IN.v3Normal2),vTweenFactor);
	float4 v4Diffuse=lerp(IN.vVertexCol,IN.vVertexCol2,vTweenFactor);
	float2 vTexCoords=IN.vTexCoords;
#else
	float4 v4Position=IN.v4Position;
	float3 v3Normal=tosigned(IN.v3Normal);
	float4 v4Diffuse=IN.vVertexCol;
	float2 vTexCoords=IN.vTexCoords;
#endif
	
#ifdef WOBBLEENABLED
	float fWobble = cos(fWobbleWaveLength * (vEngineTime - (IN.vTexCoords.x * fWobbleUSpeed) - (IN.vTexCoords.y * fWobbleVSpeed)));
	v4Position.xyz += fWobblePosAmplitude * v3Normal * fWobble;
	v3Normal.x += fWobbleNorAmplitude * fWobble;
#endif

	CalcTextureCoords(OUT.vTexCoords.xy,vTexCoords.xy);
	CalcPosition(OUT.Position,v4Position);
	OUT.Diffuse.rgb=CalculateDebugColor(v4Diffuse.rgb*v4DiffuseColor.rgb);
	OUT.Diffuse.a=v4Diffuse.a*v4Opacity.a*CalculateAlphaFade(v4Position.xyz,v3Normal);
	CalculateFog(OUT.vFog,v4Position.xyz);
	
	return OUT;
}

#if defined(MESH_STANDARD) || defined(MESH_TWEENED)
technique Ambient_Glow < string Identifier="Ambient";  string Performance="Fastest";> {
	pass p0 {
		VertexShader=compile vs_1_1 Ambient_VS10();
		PixelShader=NULL;
		
		Sampler[0]=<samplerDiffuse>;
		ColorOp[0]=MODULATE;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		ColorOp[1]=DISABLE;
		
		AlphaOp[0]=MODULATE;
		AlphaArg1[0]=TEXTURE;
		AlphaArg2[0]=DIFFUSE;
		AlphaOp[1]=DISABLE;
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif
#if defined(MESH_RIGID)

v2fStandardAmbient10 AmbientRigid_VS10(a2vStandardRigid IN)
{
	v2fStandardAmbient10 OUT;
	
	float4 v4Position=IN.v4Position;
	float3 v3Normal=tosigned(IN.v3Normal);
	float4 v4Diffuse=IN.vVertexCol;
	float2 vTexCoords=IN.vTexCoords;
	
#ifdef WOBBLEENABLED
	float fWobble = cos(fWobbleWaveLength * (vEngineTime - (IN.vTexCoords.x * fWobbleUSpeed) - (IN.vTexCoords.y * fWobbleVSpeed)));
	v4Position.xyz += fWobblePosAmplitude * v3Normal * fWobble;
	v3Normal.x += fWobbleNorAmplitude * fWobble;
#endif

	CalcTextureCoords(OUT.vTexCoords.xy,vTexCoords.xy);
	CalcPosition(OUT.Position,v4Position);
	OUT.Diffuse.rgb=CalculateDebugColor(v4Diffuse.rgb*v4DiffuseColor.rgb);
	OUT.Diffuse.a=v4Diffuse.a*v4Opacity.a*CalculateAlphaFade(v4Position.xyz,v3Normal);
	CalculateFog(OUT.vFog,v4Position.xyz);
	
	return OUT;
}

technique AmbientRigid_Glow < string Identifier="AmbientRigid";  string Performance="Fastest";> {
	pass p0 {
		VertexShader=compile vs_1_1 AmbientRigid_VS10();
		PixelShader=NULL;
		
		Sampler[0]=<samplerDiffuse>;
		ColorOp[0]=MODULATE;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		ColorOp[1]=DISABLE;
		
		AlphaOp[0]=MODULATE;
		AlphaArg1[0]=TEXTURE;
		AlphaArg2[0]=DIFFUSE;
		AlphaOp[1]=DISABLE;
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}

#endif

#if defined(MESH_WEIGHTED)
v2fStandardAmbient10 AmbientHQ_MPS_VS00(a2vStandardMPS IN)
{
	v2fStandardAmbient10 OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4Position=Do4MPS(IN.v4Position,i,w);
	float3 v3Normal=Do4MPS(tosigned(IN.v3Normal),i,w);
	float3 v3Tangent=Do4MPS(tosigned(IN.v3Tangent),i,w);
	float3 v3Binormal=Do4MPS(tosigned(IN.v3Binormal),i,w);
	float4 v4Diffuse=IN.v4Diffuse;
	
	CalcTextureCoords(OUT.vTexCoords.xy,IN.vTexCoords.xy);
	CalcPosition(OUT.Position,v4Position);
	OUT.Diffuse.rgb=CalculateDebugColor(v4Diffuse.rgb*v4DiffuseColor.rgb);
	OUT.Diffuse.a=v4Diffuse.a*v4Opacity.a*CalculateAlphaFade(v4Position.xyz,v3Normal);
	CalculateFog(OUT.vFog,v4Position.xyz);
	
	return OUT;
}

technique AmbientHQ_MPS_VS20_PS00 < string Identifier="AmbientMPS"; > {
	pass p0 {
		VertexShader=compile vs_1_1 AmbientHQ_MPS_VS00();
		PixelShader=NULL;//Ambient_PS10
		
		Sampler[0]=<samplerDiffuse>;
		ColorOp[0]=MODULATE;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		ColorOp[1]=DISABLE;
		
		AlphaOp[0]=MODULATE;
		AlphaArg1[0]=TEXTURE;
		AlphaArg2[0]=DIFFUSE;
		AlphaOp[1]=DISABLE;
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif

////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////

#ifdef REFLECTIONENABLED

#define REFLECTION_RENDERSTATES \
	AlphaBlendEnable=true; \
	SrcBlend=One; \
	DestBlend=One; \
	CullMode=<Culling>; \
	ZFunc=Equal; \
	FogEnable=<FogEnabled>; \
	FogColor=float4(0,0,0,1) \
		
struct v2fStandardReflection {
	float4 Position:			POSITION;
	float4 Reflection:			COLOR0;
	float3 vTexCoordsCube:		TEXCOORD0;
	float2 vTexCoordsMask:		TEXCOORD1;
	float vFog:					FOG;
};

#if defined(MESH_STANDARD) || defined(MESH_TWEENED)

v2fStandardReflection Reflection_VS10(a2vStandard IN) {

	v2fStandardReflection OUT;
	
	float4 v4Position = IN.v4Position;
	float3 v3Normal = tosigned(IN.v3Normal);

#ifdef WOBBLEENABLED
	float fWobble = cos(fWobbleWaveLength * (vEngineTime - (IN.vTexCoords.x * fWobbleUSpeed) - (IN.vTexCoords.y * fWobbleVSpeed)));
	v4Position.xyz += fWobblePosAmplitude * v3Normal * fWobble;
	v3Normal.x += fWobbleNorAmplitude * fWobble;
#endif

	CalcPosition(OUT.Position,v4Position);
	CalcTextureCoords(OUT.vTexCoordsMask,IN.vTexCoords);
	CalculateFog(OUT.vFog,v4Position.xyz);
	
	// Create object to tangent space matrix
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),v3Normal);
	
	// Create matrix to transform from tangent space to cube space
	float3x3 m33ObjToCubeSpace;
	m33ObjToCubeSpace[0]=m34ObjToCubeSpace[0].xyz;
	m33ObjToCubeSpace[1]=m34ObjToCubeSpace[1].xyz;
	m33ObjToCubeSpace[2]=m34ObjToCubeSpace[2].xyz;
//	OUT.TangentToCubeSpace0.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[0].xyz);
//	OUT.TangentToCubeSpace1.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[1].xyz);
//	OUT.TangentToCubeSpace2.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[2].xyz);
	
	// And move colors over
	OUT.Reflection=v4ReflectionColor*IN.vLightCol;
	float3 eye = normalize(v4EyePosObject.xyz-v4Position.xyz);
	OUT.vTexCoordsCube=2*dot(eye,v3Normal)*v3Normal-eye;		//reflected vector for cubemap lookup
	OUT.vTexCoordsCube=mul(m33ObjToCubeSpace,OUT.vTexCoordsCube);	//transform

	return OUT;
}

technique GlowReflection_FFP < string Identifier="Reflection"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 Reflection_VS10();
		PixelShader=NULL;//compile ps_2_0 Reflection_PS20();
		
		Sampler[0]=<samplerEnvironment>;
		ColorOp[0]=MODULATE;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		Sampler[1]=<samplerReflectionMask>;
		ColorOp[1]=MODULATE;
		ColorArg1[1]=TEXTURE;
		ColorArg2[1]=CURRENT;
//		Sampler[2]=<samplerReflectionFallOff>;	//does gf4mx have 3 blendstages?
//		ColorOp[2]=MODULATE;
//		ColorArg1[2]=TEXTURE;
//		ColorArg2[2]=CURRENT;
		ColorOp[2]=DISABLE;
		
		CONSTANT[0]=0xffffffff;
		AlphaOp[0]=SELECTARG1;
		AlphaArg0[0]=CONSTANT;
		AlphaArg1[0]=CONSTANT;
		AlphaOp[1]=DISABLE;
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
		REFLECTION_RENDERSTATES;
	}
}
#endif
#if defined(MESH_RIGID)
technique GlowReflectionRigid_FFP < string Identifier="ReflectionRigid"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 Reflection_VS10();
		PixelShader=NULL;//compile ps_2_0 Reflection_PS20();
		
		Sampler[0]=<samplerEnvironment>;
		ColorOp[0]=MODULATE;
		ColorArg1[0]=TEXTURE;
		ColorArg2[0]=DIFFUSE;
		Sampler[1]=<samplerReflectionMask>;
		ColorOp[1]=MODULATE;
		ColorArg1[1]=TEXTURE;
		ColorArg2[1]=CURRENT;
//		Sampler[2]=<samplerReflectionFallOff>;	//does gf4mx have 3 blendstages?
//		ColorOp[2]=MODULATE;
//		ColorArg1[2]=TEXTURE;
//		ColorArg2[2]=CURRENT;
		ColorOp[2]=DISABLE;
		
		CONSTANT[0]=0xffffffff;
		AlphaOp[0]=SELECTARG1;
		AlphaArg0[0]=CONSTANT;
		AlphaArg1[0]=CONSTANT;
		AlphaOp[1]=DISABLE;
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
		REFLECTION_RENDERSTATES;
	}
}
#endif
#endif	//REFLECTIONENABLED
